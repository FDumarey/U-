#include <Core/Core.h>
#include <MySql/MySql.h>
#include <iostream> // library for console streaming

using namespace Upp;

#define SCHEMADIALECT <MySql/MySqlSchema.h> // using the MySQL schema definitions
#define MODEL <MariaDB/schema.sch> // your schema file within MyApps
#include <Sql/sch_header.h>
#include <Sql/sch_source.h>
#include <Sql/sch_schema.h>

CONSOLE_APP_MAIN
{
	char input; // a char type for user interaction on the console
	std::cout << "Demo application on MariaDB database\n"; // send text to the console
	std::cin >> input; // press ENTER to continue
	
	MySqlSession session; // define a MySQL session variable
	if(session.Connect("root", "2001Frederik!", "test", "192.168.0.125", 3307)) //user, password, database name, host, port
	{
		std::cout << "Connected to database\n"; // connection successful
		std::cin >> input; // press ENTER to continue
		
		SQL = session; // SQL is a global variable, ok if you work with one database in project
		
		SqlSchema sch(MY_SQL); // defines a MySQL schema
		All_Tables(sch); // generate SQL scripts in the schema file
		
		SqlPerformScript(sch.Upgrade()); // update the tables and columns if needed
		SqlPerformScript(sch.Attributes()); //update the constraints and indices if needed
		SQL.ClearError(); // clear all errors before executing real queries
		
		try // we will do exception handling with the & operator, so a try...catch statement
		{
			int i; // define an integer for a loop
			for(i=0;i<100;i++) // make a loop of 101 iterations
			{
				SQL & Insert(TEST_TABLE)(VALUE, Uuid::Create().ToString()); // insert some data & operator = exception handling in code
			}
			
			Sql sql; // define a Sql object
			
			sql * Select(ID, VALUE).From(TEST_TABLE).OrderBy(Descending(ID)).Limit(5); // selects data using * operator = manual check for errors
			
			while(sql.Fetch()) // fetch data from the sql query
				Cout() << AsString(sql[0]) << ":" << AsString(sql[VALUE]) << "\n"; // use SqlId defined in the schema for returning values from the query
		}
		catch(SqlExc &ex) // catch errors of type SqlExc(eption)
		{
			Cerr() << "ERROR: " << ex << "\n"; // show the error
			SetExitCode(1); // exits the application with error code 1 (0=no error)
		}
		
	}
	else
	{
		Cerr() << "ERROR: Unable to connect to the database\n"; // manually sets an error
		SetExitCode(1); // exits the application with error code 1 (0=no error)
	}
	
	std::cout << "End of application\n"; // application ended normally
}
