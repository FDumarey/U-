#include <Core/Core.h> // include core library
#include <Skylark/Skylark.h> // include skylark library
#include <MySql/MySql.h> // include mysql/mariadb connectivity

using namespace Upp;

#define SCHEMADIALECT <MySql/MySqlSchema.h> // using the MySQL schema definitions
#define MODEL <GetStart12/2SQL/myapp.sch> // your schema file within MyApps
#include <Sql/sch_header.h> // include schema files
#include <Sql/sch_source.h> // include schema files
#include <Sql/sch_schema.h> // include schema files

SKYLARK(HomePage, "") // define handler homepage to url /myapp = root
{
    Sql sql; // define a sql command
    sql * Select(ID, NAME, LASTNAME) // select query for all info in the table
          .From(PERSON) // from the table person
          .OrderBy(LASTNAME, NAME); // sorted using lastname and then name
    ValueArray person; // define a valuearray collection
    ValueMap vm; // define a valuemap collection
    while(sql.Fetch(vm)) // execute the sql query and put in valuemap collection
        person.Add(vm); // add info in valuearray
    http("PERSON", person) // define element person with the valuearray
        .RenderResult("GetStart12/2SQL/index"); // using the witz template
}

struct MyApp : SkylarkApp { // make a class inherited from SkylarkApp
	virtual void WorkThread(); // override the WorkThread function
    MyApp() { // default constructor
        root = "myapp"; // set the root URL
        threads = 1; // databases do not like threads
    #ifdef _DEBUG // if in debug mode
        prefork = 0; // main thread handles http requests
        use_caching = false; // no caching
    #endif
    }
};

void InitModel() // used for database initialization
{
#ifdef _DEBUG
    SqlSchema sch(MY_SQL); // define a mysql schema variable
    All_Tables(sch); // generate sql scripts in the schema file
    SqlPerformScript(sch.Upgrade()); // update tables and columns
    SqlPerformScript(sch.Attributes()); // update constraints and indices
    sch.SaveNormal(); // this will save all the scripts in you app directory
#endif
}

void OpenSQL(MySqlSession& mysql) // function to open a database
{
    if(!mysql.Connect("root", "2001Frederik!", "test", "192.168.0.125", 3307)) { // connect
        LOG("Can't create or open database file\n"); // error message
        Exit(1); // exit error code
    }
	#ifdef _DEBUG // if in debug mode
    mysql.LogErrors(); // log errors to the console
    mysql.SetTrace(); // log traces to the console
	#endif
    SQL = mysql; // set the global SQL variable
    SQL.ClearError(); // clear all errors before executing real queries
}

void MyApp::WorkThread() // define the worker thread
{
    MySqlSession mysql; // define a new mysql session variable
    OpenSQL(mysql); // open the database
    RunThread(); // run the thread
}

void InitDB() // function for database initialization
{
    MySqlSession sqlsession; // define a mysql session
    OpenSQL(sqlsession); // open the database
    SqlSchema sch(MY_SQL); // instance a schema variable
    All_Tables(sch); // generate sql script in schema file
    SqlPerformScript(sch.Upgrade()); // update table and columns
    SqlPerformScript(sch.Attributes()); // update constraints and indices

    SQL * Insert(PERSON)(NAME,"Joe")(LASTNAME,"Smith"); // insert some data in the table
    SQL * Insert(PERSON)(NAME,"Mike")(LASTNAME,"Carpenter"); // insert some data
    SQL * Insert(PERSON)(NAME,"Jon")(LASTNAME,"Goober"); // insert some data
}

CONSOLE_APP_MAIN // the entry macro for console applications
{
	#ifdef _DEBUG // if in debug mode
    StdLogSetup(LOG_FILE|LOG_COUT); // set log to file and console
    Ini::skylark_log = true; // set skylark logging on
	#endif
	InitDB(); // call database initialization function
    MyApp().Run(); // run the application
}
