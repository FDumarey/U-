#include <Core/Core.h>
#include <Skylark/Skylark.h> // include the Skylark library

using namespace Upp;

SKYLARK(HomePage, "") // make a handler for the root URL - http://127.0.0.1/myapp
{
    http << "<!DOCTYPE html><html><body>Welcome to Skylark web services!</body></html>";
}

SKYLARK(Param, "*/param") // make a handler to capture a single parameter
{
    http << "<!DOCTYPE html><html><body>Parameter: " << http[0] << "</html></body>";
}

SKYLARK(Params, "params/**") // make a handler for multiple parameters
{
    http << "<!DOCTYPE html><html><body>Parameters: ";
    for(int i = 0; i < http.GetParamCount(); i++) // loop through all the parameters
        http << http[i] << " "; // [] operator will show the parameter
    http << "</html></body>";
}

SKYLARK(CatchAll, "**") // make a handler for all other url's
{
    http.Redirect(HomePage); // redirect to the Homepage
}

SKYLARK(Witz, "/witz") // make a handler for the /witz URL
{
    ValueArray va; // define a value array
    va.Add(1); // add an integer
    va.Add("Hello"); // add a string
    
    ValueMap m; // define a value map type
    m.Add("key1", "first value"); // add a key and value
    m.Add("key2", "second value"); // add a key and value

    http("MyValue", "some value") // define a element MyValue with a value
        ("MyRawValue", Raw("<b>raw <u>html</u></b>")) // define an explicit raw value
        ("MyRawValue2", "<b>another raw <u>html</u></b>") // define a raw value in a value
        ("MyArray", va) // define a container type as element
        ("MyMap", m) // define a map type as element
        // render using the index witz template
        // or render using the index2 witz template for include and define example
        .RenderResult("GetStart12/2/index2");
}

SKYLARK(Get,"/get")
{
	http.RenderResult("GetStart12/2/get");
}

SKYLARK(Submit,"/submit")
{
	http("RESULT", ToUpper((String)http["id"]))
		.RenderResult("GetStart12/2/submit");
}

SKYLARK(Post,"/post")
{
	http.RenderResult("GetStart12/2/post");
}

SKYLARK(SubmitPost,"submit:POST")
{
	http("RESULT", ToUpper((String)http["id"]))
		.RenderResult("GetStart12/2/submit");
}

SKYLARK(Session, "/session")
{
    http.RenderResult("GetStart12/2/session");
}

SKYLARK(SubmitList, "submitsession:POST")
{
    Value h = http[".LIST"]; // copy current .LIST session collection to value h
    ValueArray va; // define a valuearray
    if(IsValueArray(h)) // if .LIST already contains elements
        va = h; // copy existing container to the valuearray
    va.Add(http["id"]); // add the id "name" to the collection
    http.SessionSet(".LIST", va); // set the .list session to the collection
    http.Redirect(Session); // redirect to the session url
}

SKYLARK(Ajax, "/ajax")
{
    http.RenderResult("GetStart12/2/ajax");
}

SKYLARK(Add, "add:POST")
{
    String r = AsString(Nvl(http.Int("number1")) + Nvl(http.Int("number2"))); // nvl = return first non null value
    http.Ux("result", "The result is: " + r) // replace result text by the sum in html
        .UxSet("number1", r); // set the value of number1 to the sum
}

struct MyApp : SkylarkApp { // make a class inherited from the skylarkapp class
    MyApp() // define the constructor for the application
    {
        root = "myapp"; // set the root url to myapp
        port = 80; // set the web server TCP port to 80
    	#ifdef _DEBUG // if we are in debug mode
        prefork = 0; // main process will handle http requests directly
        use_caching = false; // no caching is used
    	#endif
    }
};

CONSOLE_APP_MAIN // the entry point of the application
{
	#ifdef _DEBUG // if we are in debug mode
    StdLogSetup(LOG_FILE|LOG_COUT); // output log to log file and the console output
    Ini::skylark_log = true; // enable skylark logging
	#endif
    
    MyApp().Run(); // run our application
}
