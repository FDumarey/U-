#include "TurtleTest.h" // include the header file

using namespace Upp;

TurtleTest::TurtleTest() // define the constructor
{
	Sizeable().Zoomable(); // make the window sizeable and zoomable
	Maximize(); // maximize the window to the screen size
	Title("U++ Turtle window"); // set the title of the window
	Icon(CtrlImg::Network()); // set a icon to the window
	AddFrame(menu); // add a menu frame
	AddFrame(status); // add a status bar frame
	menu.Set(THISBACK(MainMenu)); // links the callback function to the menu
	status = "Welcome to the Turtle engine of U++"; // set status bar label field
}

void TurtleTest::About() // the about function
{
	PromptOK("{{1@5 [@9= This is the]::@2 [A5@0 U`+`+ Turtle web engine example}}"); // show dialog window
}

void TurtleTest::FileMenu(Bar& bar) // when clicking on the file menu
{
	bar.Add("About..", THISBACK(About)); // add a menu item and its callback function
	bar.Separator(); // add a separator to the menu
	bar.Add("Exit", THISBACK(Close)); // add a menu item and its callback function
}

void TurtleTest::MainMenu(Bar& bar) // define the main menu
{
	menu.Add("File", THISBACK(FileMenu)); // add a menu header and its callback function
}

void AppMainLoop() // the main loop for the web server
{
	// "Main" stuff should go in here...

	TurtleTest().Run(); // run the GUI application, our self made class
}

CONSOLE_APP_MAIN // make a console application, entry point
{

	// MemoryLimitKb(100000000); // Can aid preventing DDoS attacks.

	TurtleServer guiserver; // define a turtleserver instance
	guiserver.Host("192.168.0.207"); // set the host name of the web server
	guiserver.HtmlPort(80); // set the default web server TCP port
	guiserver.MaxConnections(100); // set the maximum number of connections
	RunTurtleGui(guiserver, AppMainLoop); // run the guiserver with the main loop function
}
