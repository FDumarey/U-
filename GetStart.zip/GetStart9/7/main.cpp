#include <CtrlLib/CtrlLib.h>

using namespace Upp;

class MouseCtrl : public Ctrl // define an inherited control for the widget
{
	public:
		virtual Value GetData() const; // default data get property
		virtual void SetData(const Value& v); // default set data property
		virtual void Paint(Draw& w); // to paint the widget
		virtual void LeftDown(Point, dword); // left mouse click
		virtual void MiddleDown(Point, dword); // middle mouse click
		virtual void RightDown(Point, dword); // right mouse click
		virtual void MouseMove(Point, dword); // mouse move function
		MouseCtrl(); // default constructor
		MouseCtrl& SetFont(Font f); // SetFont property function
		MouseCtrl& Ink(Color c); // Ink property function
		MouseCtrl& Paper(Color c); // Paper property function
				
	private:
		String text, text2; // variables that hold text fields
		Font font; // the font used for the widget
		Color ink, paper; // the colors used for the widget
};

Value MouseCtrl::GetData() const
{
	return text; // return the mouse button field
}

void MouseCtrl::SetData(const Value& v)
{
	text = v; // set the mouse button field
	Refresh(); // refresh the control
}

void MouseCtrl::Paint(Draw& w)
{
	Size size = GetSize(); // get the size of the widget
	w.DrawRect(size, paper); // draw a rectangle
	Size txtsize = GetTextSize(text, font); // get text size
	size.cx = (size.cx - txtsize.cx) / 2; // set width
	size.cy = (size.cy - txtsize.cy * 2) / 2; // set height
	w.DrawText(size.cx, size.cy - txtsize.cy / 2, text, font, ink); // draw text field 1
	w.DrawText(size.cx, size.cy + txtsize.cy / 2, text2, font, ink); // draw text field 2
}

void MouseCtrl::LeftDown(Point, dword)
{
	text = "Left"; // change text field 1
	Refresh(); // refresh the control
}

void MouseCtrl::MiddleDown(Point, dword)
{
	text = "Middle"; // change text field 1
	Refresh(); // refresh the control
}

void MouseCtrl::RightDown(Point, dword)
{
	text = "Right"; // change text field 1
	Refresh(); // refresh the control
}

void MouseCtrl::MouseMove(Point pos, dword)
{
	text2 = Format("[%d:%d]", pos.x, pos.y); // set field 2 to the coordinates
	Refresh(); // refresh the control
}

MouseCtrl::MouseCtrl()
{
	text = "---"; // init field 1 value
	text2 = "0:0"; // init field 2 value
	ink = SBlack; // init color of text
	paper = SWhite; // init color of background
	font = StdFont(); // init the text font
	SetFrame(BlackFrame()); // init the frame
}

MouseCtrl& MouseCtrl::SetFont(Font f)
{
	font = f; // set the font variable
	Refresh(); // refresh the control
	return *this; // return current control
}

MouseCtrl& MouseCtrl::Ink(Color c)
{
	ink = c; // set the ink variable
	Refresh(); // refresh the control
	return *this; // return current control
}

MouseCtrl& MouseCtrl::Paper(Color c)
{
	paper = c; // set the paper variable
	Refresh(); // refresh the control
	return *this; // return current control
}

#define LAYOUTFILE <GetStart9/7/MouseCtrl.lay> // define the layout file
#include <CtrlCore/lay.h> // include layout classes and macros

GUI_APP_MAIN // define a gui entry point
{
	WithGetStart<TopWindow> app; // macro generated template from layout name
	app.mousectrl <<= "Click"; // use the setdata operator
	CtrlLayout(app); // draw the controls on the form
	app.Run(); // show and run the application
	PromptOK(AsString(~app.mousectrl)); // use the getdata operator
}