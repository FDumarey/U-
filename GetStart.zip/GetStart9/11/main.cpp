#include <CtrlLib/CtrlLib.h>

using namespace Upp;

GUI_APP_MAIN // gui entry point
{
	TopWindow AppWin; // define a topwindow form application
	Button button; // define a button
	button.SetLabel("End").HCenterPos().BottomPos(10); // set a label and position
	button <<= AppWin.Breaker(); // assign the breaker function to the button
	AppWin.Add(button); // add the button object to the form
	AppWin.FullScreen().Run(); // run the application in full screen
}