#include <CtrlLib/CtrlLib.h>

using namespace Upp;

struct Dialog : public TopWindow { // inherit a dialog from topwindow
	Button b; // define a button
	Dialog() { // constructor
		SetRect(0,0,Zx(200),Zy(50)); // set the size
		Add(b.SetLabel("Close dialog").SizePos()); // add a button full size
		b << [=] { Close(); }; // define close action through lambda
	}
};

struct MainWindow : public TopWindow { // inherit a main window from topwindow
	Dialog dlg; // define a dialog
	Button a,b,c; // define buttons
	MainWindow() { // constructor
		SetRect(0,0,Zx(400),Zy(100)); // set the size
		Add(a.SetLabel("Open or close non-modal, owned dialog").TopPos(0,50).HSizePos()); // add button
		Add(b.SetLabel("Open or close non-modal, ownerless dialog").TopPos(50,50).HSizePos()); // add button
		Add(c.SetLabel("Open modal dialog").TopPos(100,50).HSizePos()); // add button
		a << [=] { // set lambda to button
			if(dlg.IsOpen()) // if dialog is open
				dlg.Close(); // close the dialog
			else
				dlg.Open(this); // open non-modal owned dialog
		};
		b << [=] { // set lambda to button
			if(dlg.IsOpen()) // if dialog is open
				dlg.Close(); // close the dialog
			else
				dlg.OpenMain(); // open non-modal non-owned dialog
		};
		c << [=] { // set lambda to button
			if(dlg.IsOpen()) // if dialog is open
				dlg.Close(); // close the dialog
			else
				dlg.RunAppModal(); // open modal dialog
		};
	}
};

GUI_APP_MAIN // gui entry point
{
	MainWindow().Run(); // run the application
}