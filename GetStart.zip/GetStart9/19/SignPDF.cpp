#include <CtrlLib/CtrlLib.h>
#include <Core/SSL/SSL.h> // ssl library for digital signature
#include <PdfDraw/PdfDraw.h> // pdf export library

using namespace Upp;

CONSOLE_APP_MAIN // console application
{
	PdfDraw pdf; // define pdf object
	PdfSignatureInfo pdfSSL; // define pdf signature object

	pdfSSL.cert = LoadDataFile("cert.pem"); // load certificate
	pdfSSL.pkey = LoadDataFile("pkey.pem"); // load private key
	pdfSSL.name = "Frederik Dumarey"; // set CN
	pdfSSL.location = "Belgium"; // set location
	pdfSSL.reason = "Digital signature"; // set signature reason code
	pdfSSL.contact_info = "frederik.dumarey@telenet.be"; // set contact info

	pdf.DrawText(200, 200, "Hello world!", Serif(200), Magenta()); // draw text
	pdf.DrawEllipse(310,500,80,60,LtBlue(),5,Red()); // draw an ellipse filled with light blue, width 5 pixels and contour color red
	DrawJPEG(pdf, 100, 1000, 2000, 940, LoadDataFile("1.jpg")); // add a jpg bitmap

	String file = GetHomeDirFile("U++.pdf"); // filename in home folder
	SaveFile(file, pdf.Finish(&pdfSSL)); // save the pdf file
	         
	LaunchWebBrowser(file); // show pdf in web browser
}