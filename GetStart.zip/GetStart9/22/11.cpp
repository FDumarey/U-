#include <CtrlLib/CtrlLib.h>

using namespace Upp;

struct TimerExample : TopWindow { // make timer class windowed
	typedef TimerExample CLASSNAME; // for thisback macro
	ArrayCtrl list; // define array control list gui element
	TimeCallback tm; // define a timecallback object
	
	void Alarm() { // a callback function for the timer
		list.Add("Timer invoked at " + AsString(GetSysTime())); // add time to list
	}
	
	TimerExample() { // constructor
		list.NoHeader().AddColumn(); // add list with one column
		Add(list.SizePos()); // show list adapted to window size
		SetTimeCallback(-2000, THISBACK(Alarm)); // use settimecallback method
		tm.Set(-1000, THISBACK(Alarm)); // use timecallback method
	}
};


GUI_APP_MAIN
{
	TimerExample().Run(); // run the timer example class
}