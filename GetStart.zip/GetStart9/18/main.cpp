#include <CtrlLib/CtrlLib.h>

using namespace Upp;

#define IMAGECLASS Tray // define the image class
#define IMAGEFILE  <GetStart9/18/tray.iml> // define the image file
#include <Draw/iml.h> // import the image designer library

struct App : TrayIcon { // inherit our app from the trayicon class
	virtual void LeftDouble() { // override double left click
		Icon(Tray::Icon1()); // switch the tray icon
		PromptOK("You double clicked the tray icon or clicked on menu item Info!"); // show some ok dialog with text
		Icon(Tray::Icon()); // switch the tray icon back to original
	}
	
	virtual void LeftDown() { // override left click
		Info("Tray icon example", "You clicked on the tray icon\n""This is an information"); // show an OS information
	}

	virtual void Menu(Bar& bar) { // add a menu to the tray icon application
		bar.Add("Info..", THISBACK(LeftDouble)); // add an info bar that calls left double click
		bar.Separator(); // add a menu separator
		bar.Add("Exit", THISBACK(Break)); // add a exit menu bar that exits the application
	}

	typedef App CLASSNAME; // define app for callback functions

	App() { // the application constructor
		Icon(Tray::Icon()); // add a initial icon to the tray icon application
		Tip("This is our Tray icon example"); // add a tooltip to the tray icon
	}
};
 
GUI_APP_MAIN // gui main entry point
{
	App().Run(); // launch the application
}