#include <CtrlLib/CtrlLib.h>

using namespace Upp;

#define LAYOUTFILE <GetStart9/15/layouttabs.lay> // define the tabs layout file
#include <CtrlCore/lay.h> // convert to templates

struct FirstTabDlg : WithTab1<ParentCtrl> { // use tab1 layout with parentctrl inheritance
	typedef FirstTabDlg CLASSNAME; // define the classname
	FirstTabDlg(); // constructor prototype
};

FirstTabDlg::FirstTabDlg() // constructor for first tab
{
	CtrlLayout(*this); // places widgets into positions
}

struct SecondTabDlg : WithTab2<ParentCtrl> { // use tab2 layout with parentctrl inheritance
	typedef SecondTabDlg CLASSNAME; // define the classname
	SecondTabDlg(); // constructor prototype
};

SecondTabDlg::SecondTabDlg() // constructor for second tab
{
	CtrlLayout(*this); // places widgets into position
}

#undef LAYOUTFILE // undefine the first layout file
#define LAYOUTFILE <GetStart9/15/layoutmain.lay> // define the main layout file
#include <CtrlCore/lay.h> // convert to templates

struct MainDlg : WithMain<TopWindow> { // use main layout with topwindow inheritance
	typedef MainDlg CLASSNAME; // define the classname
	FirstTabDlg  tab1; // instance a tab 1
	SecondTabDlg tab2; // instance a tab 2
	void DoDialog(); // info dialog prototype
	MainDlg(); // constructor prototype
};

void MainDlg::DoDialog() // information dialog function
{
	WithInfo<TopWindow> dlg; // variant without class, good for simple modal dialogs
	CtrlLayoutOK(dlg, "Information dialog"); // ok means dialog has normal 'ok' button that needs setting up
	if(dlg.Execute() != IDOK) // if OK button is pressed
		return; // exit function
}

MainDlg::MainDlg() // main constructor
{
	CtrlLayout(*this, "Layouts"); // set the widgets and the windows title
	tab.Add(tab1.SizePos(), "First page"); // add tab1 instance to the tabctrl
	tab.Add(tab2.SizePos(), "Second page"); // add tab2 instance to the tabctrl
	tab1.btnInfo <<= THISBACK(DoDialog); // set callback function for info ok button
}

GUI_APP_MAIN // main gui entry point
{
	MainDlg().Run(); // run the main application
}