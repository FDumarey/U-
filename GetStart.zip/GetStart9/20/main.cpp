#include <CtrlLib/CtrlLib.h>
#include <GLDraw/GLDraw.h> // opengl draw wrapper library
#include <GLCtrl/GLCtrl.h> // opengl library

using namespace Upp;

struct OpenGLExample : GLCtrl { // inherit a opengl widget control
	Point point; // define a point

	virtual void GLPaint() { // override painting the canvas
		StdView(); // standard viewport
		Size sz = GetSize(); // get window size
				
		double ty = 10 * point.x; // calculate modifier y
		double tx = 10 * point.y; // calculate modifier x
				
		/* opengl example 1
		// remove comments to run
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glClearColor(0.1, 0.39, 0.88, 1.0);
  		glEnable(GL_CULL_FACE);
  		glCullFace(GL_BACK);
  		glMatrixMode(GL_PROJECTION);
  		glLoadIdentity();
  		glFrustum(-2, 2, -1.5, 1.5, 1, 40);
  		glMatrixMode(GL_MODELVIEW);
  		glLoadIdentity();
  		glTranslatef(0, 0, -3);
  		glRotatef(tx/50, 1, 0, 0);
  		glRotatef(ty/70, 0, 1, 0);
  		
  		glColor3f(1.0, 1.0, 1.0);
  		glBegin(GL_LINES);
  		for (GLfloat i = -2.5; i <= 2.5; i += 0.25) {
    		glVertex3f(i, 0, 2.5); glVertex3f(i, 0, -2.5);
    		glVertex3f(2.5, 0, i); glVertex3f(-2.5, 0, i);
  		}
  		glEnd();
		
		glBegin(GL_TRIANGLE_STRIP);
    	glColor3f(1, 1, 1); glVertex3f(0, 2, 0);
    	glColor3f(1, 0, 0); glVertex3f(-1, 0, 1);
    	glColor3f(0, 1, 0); glVertex3f(1, 0, 1);
    	glColor3f(0, 0, 1); glVertex3f(0, 0, -1.4);
    	glColor3f(1, 1, 1); glVertex3f(0, 2, 0);
    	glColor3f(1, 0, 0); glVertex3f(-1, 0, 1);
  		glEnd();
  		glFlush();
  		
  		*/
  		// opengl gldraw example
  		// remove comments to run
  		GLDraw drawdc; // define a opengl draw object
		drawdc.Init(sz); // initialize the viewport
		for(int angle=0; angle<360; angle+=15) // draw rotated text
			drawdc.DrawTextA(sz.cx - sz.cx/3, sz.cy-sz.cy/3, angle*10, "OpenGL DrawText");
		drawdc.End(); // end the drawing operations
	}
	
	virtual void GLResize(int w, int h) { // override resizing the window
		glViewport(0, 0, (GLsizei)w, (GLsizei)h); // adapt the viewport
	}
	
	virtual void MouseMove(Point p, dword) { // override the mouse move
		point = p; // set the point for modifier
		Refresh(); // call the paint function
	}
};

GUI_APP_MAIN // gui entry point
{
	Ctrl::GlobalBackPaint(); // set the background black
	TopWindow win; // define a top window form
	OpenGLExample gl; // instance a opengl custom widget
	gl.SetFrame(InsetFrame()); // draw an inset frame
	win.Add(gl.HSizePos(10, 10).VSizePos(10, 10)); // add the gl widget to the form
	win.Sizeable().Zoomable(); // set the window sizeable and zoomable
	win.Open(); // open the window
	win.Run(); // run the application
}