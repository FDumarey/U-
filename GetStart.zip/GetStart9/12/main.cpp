#include <CtrlLib/CtrlLib.h>

using namespace Upp;

#define IMAGECLASS ImagesImg // define the class of the icons
#define IMAGEFILE <GuiImages/images.iml> // define the icon file
#include <Draw/iml.h> // import images library

class MyApp : public TopWindow { // define a new window form from topwindow
	public:
		Image img, img2; // define two bitmaps
		FileSel fs; // define a file selector
		virtual void Paint(Draw& w); // override the ctrl paint function
		void Open(); // function to open a file
		virtual void LeftDown(Point, dword) { Open(); } // override the left mouse click and connect to the open function
		typedef MyApp CLASSNAME; // used for callback functions
		MyApp(); // default constructor
};

MyApp::MyApp() { // default constructor
	fs.Type("Image file", "*.bmp;*.png;*.tif;*.tiff;*.jpg;*.jpeg;*.gif"); // choose extensions for file selector
	ImageBuffer ib(50,50); // define a bitmap buffer 50*50 pixels
	for (int y=0; y<50; y++) { // loop through all lines of the buffer
		RGBA *line = ib[y]; // set a pointer to each beginning of the line
		for (int x=0; x<50; x++) { // loop through all columns (x-coordinates) of the bitmap
			if (y==0 || y==49 || x==0 || x==49) // if we have a border coordinate
				*line++ = Black(); // set the pixel black and move to the next pixel
			else { // if no border pixel
				line->a=2*(x+y); // set the alpha value to 2 * (x+y)
				line->r=4*x; // set the red value to 4 * x
				line->g=4*y; // set the green value to 4 * y
				line->b=2*(x+y); // set the blue value to 2 * (x+y)
				line++; // move to the next pixel
			}
		}
	}
	Premultiply(ib); // already multiply the alpha value
	img = ib; // set the image to the image memory buffer
}

void MyApp::Open() { // the open file function
	if (fs.ExecuteOpen("Choose the image file to open")) { // display the standard file open dialog
		img2 = StreamRaster::LoadFileAny(~fs); // load a bitmap file in a bitmap image
		Refresh(); // refresh the ctrl, calling the paint function
	}
}

void MyApp::Paint(Draw& w) { // paint the ctrl area
	w.DrawRect(GetSize(), White()); // set a white background
	w.DrawImage(10,5, img); // draw our created bitmap
	w.DrawImage(40,25,img); // draw an overlapped bitmap to see the alpha channel working
	w.DrawImage(0,300,img2); // draw the file selected bitmap
	for (int i=0; i < ImagesImg::GetCount(); i++) { // loop through the icons in the iml file
		w.DrawImage(50, 100+50*i, ImagesImg::Get(i)); // show the icons
		w.DrawText(100,100+50*i, ImagesImg::GetId(i)); // show the name of the icons
	}
}

GUI_APP_MAIN // main gui entry point
{
	MyApp().Sizeable().Run(); // run the application in a resizable form
	
}