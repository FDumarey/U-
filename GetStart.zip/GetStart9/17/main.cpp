#include <CtrlLib/CtrlLib.h>
#include <plugin/jpg/jpg.h> // using the jpeg library

using namespace Upp;

GUI_APP_MAIN // gui entry point
{
	FileSel fs; // define file selector dialog
	fs.Type("Image file", "*.bmp; *.png; *.tif; *.tiff; *.jpg; *.jped; *.gif"); // define raster types
	if(!fs.ExecuteOpen("Choose the image file to convert")) // open file select dialog
		return; // if error stop program
	String fn = ~fs; // get the filename
	JPGEncoder jpg(20); // define a jpeg encoding stream with quality 20
	FileIn in(fn); // open a file stream
	One<StreamRaster> raster = StreamRaster::OpenAny(in); // define and open a streamraster stream
	if(!raster) { // if an error occurs on the streamraster
		Exclamation("Invalid file format"); // show exclamation dialog
		return; // exit the program
	}
	FileOut out (fn + ".out.jpg"); // define a file write stream
	jpg.SetStream(out); // set a write jpeg stream using filename
	jpg.Create(raster->GetSize()); // create needs the size of the jpeg bitmap
	for(int i=0; i<raster->GetHeight(); i++) { // loop through all lines of the bitmap
		RasterLine l = raster->GetLine(i); // define a raster line and get it from the stream
		Buffer<RGBA> out(raster->GetWidth()); // define a rgba buffer with size getwidth pixels
		for (int j=0; j<raster->GetWidth(); j++) { // loop through a line for all pixels
			out[j].g = out[j].b = out[j].r = l[j].g; // set monotone color to initial green value
			out[j].a = 255; // no transparency
		}
		jpg.WriteLine(out); // write and close the jpeg output stream
	}
}