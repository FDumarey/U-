#include <CtrlLib/CtrlLib.h>

using namespace Upp;

struct MyApp : TopWindow{ // inherits a struct from TopWindow
	DropList font_list; // define a droplist widget variable
	
	virtual void Paint(Draw& w) override { // override the paint event from TopWindow
		const String text = "Programming is fun!"; // define a string variable
		Font fnt(~font_list, 60); // ~ operator = get property of droplist, font size 60 pixels
		w.DrawRect(GetSize(),White); // make the background white
		w.Offset(50,50); // set an offset of 50 pixels horizontal and vertical
		int x=0; // set x=0
		Vector<int> dx; // define a collection of integers
		
		for (char letter : text) { // loop through all characters in the text variable
			int width = fnt[letter]; // [] operator gets letter width
			w.DrawRect(x,0,width-1, fnt.GetAscent(), Color(255,255,200)); // ascent = baseline to top of character
			w.DrawRect(x, fnt.GetAscent(), width-1, fnt.GetDescent(), Color(255,200,255)); // descent = baseline to bottom of character
			w.DrawRect(x+width-1, 0, 1, fnt.GetHeight(), Black()); // getheight = total height of the character
			dx.Add(width+4); // add 4 to the width of the character and add it to the collection
			x += width; // increase x with the character width
		}
		
		w.DrawRect(0,0,4,4,Black()); // draw a black rectangle
		w.DrawText(0,0,text,fnt); // draw the text in the choosen font
		
		// draw the text in blue color, dx.getcount number of characters
		// and a spacing between the individual characters in the collection dx
		w.DrawText(0,70,text,fnt,Blue(),dx.GetCount(),dx.begin());
		
		w.End(); // ends the offset and clipping settings
	}
	
	void NewFont() { // define a function when a new font is choosen
		Refresh(); // marks the whole view for repainting
	}
	
	MyApp() {
		for(int i=0; i < Font::GetFaceCount(); i++) // for all known fonts in the OS
			font_list.Add(i, Font::GetFaceName(i)); // add the name to the droplist widget
		
		// add a control droplist to the application window
		// height toppos from 0 to the minimum size of the widget (ctrl)
		// width from 0 to 200 pixels
		Add(font_list.TopPos(0, MINSIZE).LeftPosZ(0, 200));
		
		font_list <<= 0; // <<= operator will select item 0
		font_list << [=] { NewFont(); }; // << operator adds a lambda function to the selected event of a droplist widget
	}
};


GUI_APP_MAIN
{
	MyApp().Sizeable().Run(); // starts an instance of the Myapp struct in a sizeable window
}
