#include <CtrlLib/CtrlLib.h>

using namespace Upp;

String GetKeyDescEx(int key) // function to return extended key description
{
		String desc = GetKeyDesc(key & ~K_KEYUP); // get extended key string
        if(key & K_KEYUP) desc << " UP"; // if key_up event add text
        return desc; // return description string
}

struct App : TopWindow // define app from a windows forms class
{
		ArrayCtrl  log; // define an array control

        void Log(const String& s) // function to write to array control
        {
        	log.Add(s); // add a string to the control
            log.GoEnd(); // set cursor at last position
        }

        virtual void Activate() // override activate event
        {
            Log("Activate event called.");
        }

        virtual void Deactivate() // override deactivate event
        {
            Log("Deactivate event called.");
        }

        virtual bool Key(dword key, int count) // get key code and repeat count
        {
        	Log(Format("Key(%x, %d) ", (int)key, count) + GetKeyDescEx(key)); // show key code, repeat index, description
            return false; // go to parent objects
        }

        virtual void GotFocus() // override get focus event
        {
        	Log("GotFocus event called.");
        }

        virtual void LostFocus() // override loose focus event
        {
        	Log("LostFocus event called.");
        }
 
        virtual bool HotKey(dword key) // override get hotkey event as top ctrl event
        {
        	Log(Format("HotKey(%x) ", (int)key) + GetKeyDescEx(key)); // show key code and extended description
            return false; // go until root ctrl
        }

        virtual void ChildGotFocus() // override child ctrl got focus
        {
        	Log("ChildGotFocus event called.");
        }

        virtual void ChildLostFocus() // override child loose focus
        {
        	Log("ChildLostFocus event called.");
        }

        virtual void Layout() // override change position or size of ctrl
        {
        	Log("Layout event called.");
        }

        App() // default constructor
        {
        	SetFrame(InsetFrame()); // set a inset frame
            AddFrame(InsetFrame()); // add a inset frame
            log.AddColumn("Ctrl form events:"); // add one column to the array control
            Add(log.HSizePos().BottomPosZ(0, 300)); // add a array control to the form
        }
};

GUI_APP_MAIN // main gui entry point
{
	App().Sizeable().Zoomable().Run(); // run the application with a sizeable form
}