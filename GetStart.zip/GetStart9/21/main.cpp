#include <CtrlLib/CtrlLib.h>

#include <plugin/png/png.h>
#include <plugin/bmp/bmp.h>
#include <plugin/gif/gif.h>
#include <plugin/jpg/jpg.h>
#include <plugin/tif/tif.h>

using namespace Upp;

GUI_APP_MAIN // gui entry point
{
	ImageDraw id(800, 600); // define an image draw of 800*600 pixels
	id.DrawEllipse(0,0,800,600,LtGreen(),10,White()); // draw a full screen ellipse
	id.DrawText(80, 260, "Writing image to encoders.", Arial(50), Black()); // draw some text
	DrawFatFrame(id, 0, 0, 800, 600, White(), 2); // set a outer frame
	Image im = id; // define an image, and copy the drawing to it

	PNGEncoder png; // define a png object
	png.Bpp(1); // set color depth to 1 bit
	png.SaveFile(GetExeDirFile("image.png"), im); // save the image to the executable directory
	
	BMPEncoder bmp; // define a bmp object
	bmp.Bpp(32); // set color depth to 32 bit
	bmp.SaveFile(GetExeDirFile("image.bmp"), im); // save the image to the executable directory 

	GIFEncoder gif; // define a gif object
	gif.SaveFile(GetExeDirFile("image.gif"), im); // save the image to the executable directory

	JPGEncoder jpg; // define a jpg object
	jpg.Quality(20); // set the quality to 20%
	jpg.SaveFile(GetExeDirFile("image.jpg"), im); // save the image to the executable directory
	 
	TIFEncoder tif; // define a tif object
	tif.Bpp(8); // set color depth to 8 bit
	tif.SaveFile(GetExeDirFile("image.tif"), im); // save the image to the executable directory
}