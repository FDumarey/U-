#include <CtrlLib/CtrlLib.h>

using namespace Upp;

#define LAYOUTFILE <GetStart9/6/dlg.lay> // define the location of the layout file
#include <CtrlCore/lay.h> // import the layout library

struct MyAppWindow : public WithDlgLayout<TopWindow> { // class inherits a layout dialog class
	MyAppWindow() { // constructor
		CtrlLayout(*this, "My Dialog"); // sets title and set all widgets from the layout file
		ok.Ok() << Acceptor(IDOK); //set acceptor return value for the ok button
		cancel.Cancel() << Rejector(IDCANCEL); // set rejector return value for the cancel button
	}
};

GUI_APP_MAIN // entry point for GUI application
{
	MyAppWindow app; // instances a layout dialog window
	app.text.SetData("Some text"); // set text property of text label
	app.date1 <<= app.date2 <<= app.date3 <<= GetSysDate(); // sets system date to date widgets
	app.date1.ClearModify(); //set flag to unmodified property for date1 widget
	app.date2.Disable(); // set disable editing for date2 widget
	app.date3.SetReadOnly(); //set date3 widget as read-only
	switch (app.Run()) { // gets the return value of the destructor of the class instance
		case IDOK: // if acceptor
			PromptOK("OK was pressed"); // show message box OK
			break; // break switch statement
		case IDCANCEL: // if rejector
			Exclamation("Canceled"); // show message box canceled
	}
	
	if (app.date1.IsModified()) PromptOK("Date was modified!"); // check if date1 was modified
	PromptOK((String) app.text.GetData()); // show the text widget property in a message box
}
