#include <CtrlLib/CtrlLib.h>

using namespace Upp;

String apikey = "AIzaSyCOBwgHI035y6s6CHu07AfhG4_5C220-cM"; // the API key of your project and account

String GetGoogleMap(double center_x, double center_y, int zoom, int cx, int cy, const char* format, String *error) { // function to make a web api request to google static map
	String request; // define a http request string
	request << "http://maps.google.com/maps/api/staticmap?center=" << AsString(center_y) << ',' << AsString(center_x) << // make the correct string
		"&zoom=" << zoom << // using all the correct parameters in the api request
		"&size=" << cx << 'x' << cy <<
		"&format=" << format << // the file format of the request
		"&sensor=false&key=" << apikey; // our custom api key
	HttpRequest r(request); // define a httprequest variable
	String h = r.Execute(); // execute the http request and get the answer
	if (r.IsFailure()) // if an error occured
		*error = r.GetErrorDesc(); // get the error description
	return h; // return the web server answer
}

Image GetGoogleMapImage(double center_x, double center_y, int zoom, int cx, int cy, const char* format, String *error) { // function to get the image of a google static map request
	return StreamRaster::LoadStringAny(GetGoogleMap(center_x, center_y, zoom, cx, cy, format, error)); // get the request and put in an image streamraster
}

struct MyApp : TopWindow { // define a topwindow inherited struct
	Image img; // define our image
	
	virtual void Paint(Draw& w) { // override the paint event
		w.DrawRect(GetSize(), Gray()); // draw a background gray rectangle
		w.DrawImage(0,0,img); // draw the image on the ctrl
	}
	
	MyApp() { // define the constructor
		String* error; // define an error string pointer
		img = GetGoogleMapImage(-73.998672, 40.714728, 12, 600, 600, "png", error); // get a google static map api image
		//LOG(*error); // for debugging reasons
	}
};

GUI_APP_MAIN // main gui entry point
{
	MyApp().Sizeable().Zoomable().Run(); // run the application in a resizable, zoomable window
}