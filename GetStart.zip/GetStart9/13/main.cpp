#include <CtrlLib/CtrlLib.h>
#include <chrono> // high precision timers

using namespace Upp;

class CachedImage : public ImageMaker // inherit cached image base class
{
	public:
		Color color; // a color member variable
		int x; // a size member variable
		virtual String Key() const; // override unique identifier
		virtual Image Make() const; // override cached image maker
};

String CachedImage::Key() const // function to define unique identifier
{
	return Format("%03d%03d%03d%03d", x, color.GetR(), color.GetB(), color.GetG()); // return a key based upon size and color
}

Image CachedImage::Make() const // function to define cached image
{
	ImageBuffer b(x,x); // define a image buffer x * x pixels size
	for(int yy=0;yy<x;yy++) // loop through vertical size
		for(int xx=0;xx<x;xx++) // loop through horizontal size
		{
			RGBA& a = b[yy][xx]; // make a reference to a pixel in the buffer variable
			a.r = color.GetR(); // set the red value
			a.g = color.GetG(); // set the green value
			a.b = color.GetB(); // set the blue value
			int q = x*xx - x*yy; // calculate an alpha value to have a triangle form
			a.a = q <= 255 ? q : 0; // if q < 255 use color otherwise make transparent
		}
		Premultiply(b); // pre multiply the alpha value
		return b; // return the buffered image
}

Image CreateImage(int x, Color color) // function to create a single image
{
	CachedImage m; // instance a cached image
	m.x = x; // set the size parameter
	m.color = color; // set the color parameter
	return MakeImage(m); // return the cached image
}

class MyApp : public TopWindow // make an gui application class
{
	public:
		virtual void Paint(Draw& w) // override the paint event
		{
			auto start = std::chrono::high_resolution_clock::now(); // take a snapshot of current time
			w.DrawRect(GetSize(), Black()); // make the background black
			for (int y=0; y<500; y+=50) // loop through vertical values
				for (int x=0;x<500;x+=25) // loop through horizontal values
				{
					Color c = Color((x)&255, (2*x)&255, (3*x)&255); // define a color value
					w.DrawImage(x, y, CreateImage(x, c)); // call the cached image function
				}
			auto duration = std::chrono::high_resolution_clock::now() - start; // calculate time duration
			auto result=std::chrono::duration_cast<std::chrono::milliseconds>(duration).count(); // convert duration to milliseconds
			Title(AsString(result) + " milliseconds elapsed for drawing operation."); // set the title of the application to the duration
		}
};

GUI_APP_MAIN // gui entry point macro
{
	MyApp().Sizeable().Zoomable().Run(); // run the application with a sizeable window
}