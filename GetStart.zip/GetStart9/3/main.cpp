#include <CtrlLib/CtrlLib.h>

using namespace Upp;

struct MyApp: TopWindow { // define a class of topwindow
	Drawing drawing; // set of drawing operations to form a vector image
	
	virtual void Paint(Draw& w) override { // override the paint event of topwindow
		w.DrawRect(GetSize(), White()); // paint the background white
		w.DrawDrawing(10,10,50,60, drawing); // paint the drawing vector within the bounds
		w.DrawDrawing(100,10,150,100, drawing); // paint the drawing vector within other bounds
		w.DrawDrawing(10,110,300,300, drawing); // paint the drawing vector within other bounds
	}
	
	MyApp() {
		DrawingDraw iw(200,200); // define a vector drawing with size 200*200
		iw.DrawEllipse(10,10,180,100, Cyan()); // draw an ellipse in the vector context
		iw.DrawImage(100,100, CtrlImg::exclamation()); // draw a bitmap in the vector context
		iw.DrawRect(20,100,30,30, Blue); // draw a rectangle in the vector context
		drawing = iw; // copy the drawing operations to a vector instance
	}
};

GUI_APP_MAIN
{
	MyApp().Sizeable().Run(); // run the topwindow object
}
