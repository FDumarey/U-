#include <CtrlLib/CtrlLib.h>

using namespace Upp;

struct MyApp: TopWindow{ // define a topwindow structure
	Image image; // define a bitmap
	
	virtual void Paint(Draw& w) override { // override the paint method
		w.DrawRect(GetSize(),Cyan());  // make the background cyan
		w.DrawImage(10,10,image); // draw the bitmap
		w.DrawImage(80,30,image); // draw the bitmap again to see the alpha channel in action
	}
	
	MyApp() {
		ImageDraw iw(100,40); // define a bitmap drawing context
		iw.Alpha().DrawRect(0,0,100,40,GrayColor(0)); // rectangle on alpha layer, defined by GrayColor(x)
		iw.Alpha().DrawEllipse(0,0,100,40,GrayColor(255)); // ellipse on alpha layer, 255 = non-transparant
		iw.DrawEllipse(0,0,100,40,Yellow()); // draw a yellow ellipse
		iw.DrawText(26,10,"Image", Arial(16).Bold()); // draw some text
		image=iw; // set the bitmap to the series of imagedraw operations
	}
};

GUI_APP_MAIN
{
	MyApp().Sizeable().Run(); // run an sizeable window instance of the struct/class
}
