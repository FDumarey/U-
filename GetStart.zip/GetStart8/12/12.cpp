#include <Core/Core.h>
#include <Core/POP3/POP3.h>
#include <Core/SMTP/SMTP.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	// SMTP send a test mail
	
	String user = "frederik.dumarey@telenet.be"; // set user name
	String pwd = "2001FrederikDumarey"; // set password
	Smtp mailsmtp; // instance from smtp class
	Smtp::Trace(); // activate tracing
	mailsmtp.Host("smtp.telenet.be") // set the host name
		    .Port(465) // set the tcp port
		    .SSL() // set use of TLS/SSL certificates
			.Auth(user, pwd) // authenticate the user
			.To(user) // send mail to own user
			.Subject("Mail from U++ framework") // set a subject
		    .Body("This is a test mail with some attachments.") // set the mail body
		    .Attach("text.txt", "This is a test of a String attachment") // add a text attachment
		    .AttachFile(GetDataFile("12.cpp")); // add a file attachment
	if(mailsmtp.Send()) // send the mail
		Cout() << "Mail succesfully sent\n"; // succesfully sent
	else
		Cout() << "Error sending mail, error code: " << mailsmtp.GetError() << '\n'; // error sending
		
	// POP3 receive the list of unread mails
	
	Cout() << "Press ENTER when you are ready to receive your mails [ENTER]";
	String ready = ReadStdIn(); // wait for enter
	Pop3 mailpop3; // instance a pop3 class
	mailpop3.Host("pop.telenet.be") // set the pop3 host name
            .Port(995) // set the tcp port
            .User(user, pwd) // set the credentials
            .SSL() // enable TSL/SSL certificates
            .Trace(); // activate logging of pop3
	if(!mailpop3.Login()) { // try to login
		Cout() << "Connection to mailbox failed, error code: " << mailpop3.GetLastError() << "\n"; // login failed
		return; // exit program
	}
	int msgcount = mailpop3.GetMessageCount(); // count the number of mails
	if(msgcount < 0) { // error retrieving mails
		Cout() << "Get messages failed, error code: " << mailpop3.GetLastError() << "\n";
		return; // exit the program
	}
	Cout() << "There are " << msgcount << " new messages in your inbox.\n\n"; // return number of messages
	for(int i=1; i<=msgcount; i++) // loop through all messages
	{
		Cout() << "Retrieving message: " << i << '\n';
		String message = mailpop3.GetMessage(i); // get the mail message
		if(IsNull(message)) // error retrieving message
			Cout() << "Error retrieving message, error code: " << mailpop3.GetLastError() << "\n";
		else {
			InetMessage mail; // define a mail object
			if(mail.Read(message)) { // read a message in the mail object
				Cout() << "Subject: " << mail["subject"] << "\n" // return the subject
					       << "From: " << mail["from"] << "\n" // return the from field
					       << "Date: " << mail["date"] << "\n" // return the date
					       << "Attachments: " << mail.GetCount() << '\n'; // return the number of attachments
				for(int j = 0; j < mail.GetCount(); j++) // loop through the attachments
					Cout() << "Attachment " << j << ", type " << mail[j]["content-type"] // get the content-type
						   << ", size: " << mail[j].Decode().GetLength() << '\n'; // get the size
					Cout() << "\n";
				}
				else
					Cout() << "Error parsing the message\n"; // error reading the mail object
			}
	}	
}