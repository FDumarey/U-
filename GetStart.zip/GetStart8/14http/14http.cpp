#include <Core/Core.h>
#include <Core/SSL/SSL.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	Cout() << "Enter the URL:\n";
	String url = ReadStdIn(); // read the url string
	String proxy = ""; // define a proxy if needed
	HttpRequest http(url); // define httprequest with url
	http.Proxy(proxy); // define the proxy server
	String contents = http.Execute(); // execute the whole http request
	Cout() << "Error: " << http.GetErrorDesc() << '\n'; // get the error code if any
	Cout() << "Status: " << http.GetStatusCode() << " , " << http.GetReasonPhrase() << '\n'; // get the http status code
	Cout() << "Content: " << contents.GetLength() << " bytes" << '\n'; // get the length of the http content
	Cout() << "Press ENTER to see the contents\n";
	url = ReadStdIn(); // wait for enter
	Cout() << contents.ToString() << '\n'; // show the contents of the http request
}