#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	// One example
	One<int> s;
	DUMP(bool(s)); //true if container has an element
	int *b = ~s; // ~ operator = gets pointer of One
	
	// Any example
	Any x;
	x.Create<String>() = "Hello";
	if (x.Is<String>()) 
		LOG("Any is now a string type with value: " << x.Get<String>());
}
