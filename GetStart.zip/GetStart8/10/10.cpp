#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	const Vector<String>& cmdline = CommandLine(); // instance cmdline variable
	int i = cmdline.GetCount(); // get number of arguments
	Cout() << "Number of arguments: " << i << '\n'; // show number of arguments
	for (int x=0;x<i;x++) // loop through arguments
		Cout() << "Argument " << x << " : " << cmdline[x] << '\n'; // show arguments
	Cout() << "Computer name: " << GetComputerName() << '\n'; // show computer name
	Cout() << "User name: " << GetUserName() << '\n'; // show user name
	Cout() << "Desktop manager: " << GetDesktopManager() << '\n'; // show desktop manager
	Cout() << "CPU cores: " << CPU_Cores() << '\n'; // show number of cpu cores
	SetExitCode(99); // set an application exit code
}
