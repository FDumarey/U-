#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	int x = 365;
	LOG("Value of x is " << x);
	//use RLOG for LOGS in release mode
	//use DLOG for LOGS in debug mode
	DUMPHEX(x);
	
	float pi=3.1415926;
	DUMP(pi);
	
	VectorMap<int, String> map = { {35, "house"}, {21, "appartment"}};
	DUMPM(map);
}
