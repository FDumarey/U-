#include <Core/Core.h>
#include <windows.h> //include the Win32 API

using namespace Upp;

void Alarm(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime)  // define timer callback function
{
	Cout() << "Timer callback function call with time:" << dwTime << '\n'; // show the time
}

CONSOLE_APP_MAIN
{
	MSG Msg; // define a windows message variable
	UINT TimerId = SetTimer(NULL, 0, 1000, (TIMERPROC) &Alarm); // define a timer
    Cout() << "TimerId: " << TimerId << '\n'; // show the timerid of the new timer
    if (!TimerId) SetExitCode(99); // if no timerid is returned, the exit the application
    while (GetMessage(&Msg, NULL, 0, 0)) // get messages from the desktop manager queue
    {
      if (Msg.message == WM_TIMER) Cout() << "Timer message received" << '\n'; // check if timer message
      DispatchMessage(&Msg); // get message from queue
    }
    KillTimer(NULL, TimerId); // delete the timer
    SetExitCode(0); // exit the application with error code 0
}