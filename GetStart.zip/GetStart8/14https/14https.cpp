#include <Core/Core.h>
#include <Core/SSL/SSL.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	TcpSocket server; // define a server tcp socket
    if(!server.Listen(443, 5)) { // check if listener on port 443 with 5 queues is okay
        Cout() << ("Cannot open server port for listening\r\n"); // show error message
		SetExitCode(99); // set console exit code
        return; // exit the application
    }

    for(;;) { // do a endless loop
        TcpSocket socket; // define a client socket incoming connection
        Cout() << "Waiting for connections...\n";
        if(socket.Accept(server)) { // if an incoming server connection is seen
            Cout() << "Connection accepted, initializing SSL\n";
            socket.SSLCertificate(LoadFile(GetDataFile("code.crt")),
                                  LoadFile(GetDataFile("code.key")),
                                  false); // define the certificate and private key for SSL
            if(!socket.StartSSL()) { // try to start the SSL connection
                Cout() << "Failed to start SSL, error: " << socket.GetErrorDesc() << '\n'; // error
                continue; // continue the application
            }
            while(socket.SSLHandshake()); // try a SSL handshake between server and client
            if(socket.IsError()) { // check for errors
                Cout() << "SSL handshake failed, error: " << socket.GetErrorDesc() << '\n'; // error
                continue; // continue application
            }
            Cout() << ("SSL succesfully established\n");
            HttpHeader http; // define a http header object
            if(!http.Read(socket)) { // read the http header request from the client
                Cout() << "Failed getting HTTPS header\n"; // error
                continue; // continue the application
            }
            Cout() << "HTTPS header: " << http.GetMethod() << ' ' << http.GetURI() << '\n'; // show header
            String html; // define a response string in html format
            html << "<html>"
                 << "<b>Method:</b> " << http.GetMethod() << "<br>"
                 << "<b>URI:</b> " << http.GetURI() << "<br>"; // add client info to the response
            for(int i = 0; i < http.fields.GetCount(); i++) // get through the http fields
                html << "<b>" << http.fields.GetKey(i) << ":</b> " << http.fields[i] << "<br>"; // get the http fields from the client request
            int len = (int)http.GetContentLength(); // get the length ot the http request
            if(len > 0) // if the length is not zero
                socket.GetAll(len); // get all characters from the stack
            html << "<b><i>Current time:</i></b> " << GetSysTime() << "</html>"; // add the system time to the response
            HttpResponse(socket, http.scgi, 200, "OK", "text/html", html); // send the http response to the client
            Cout() << "Request finished\n\n"; // end of request
        }
    }
}