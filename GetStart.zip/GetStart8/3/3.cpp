#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	Date date = GetSysDate();
	DUMP(date);
	DUMP((int)date.year);
	DUMP((int)date.month);
	DUMP((int)date.day);
	
	Time time = GetSysTime();
	DUMP(time);
	DUMP((int)time.hour);
	DUMP((int)time.minute);
	DUMP((int)time.second);
}
