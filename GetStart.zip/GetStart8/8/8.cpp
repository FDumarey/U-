#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	// Thread class
	
	Thread t; // define a new thread instance
	t.Run([] { // run a thread using a lambda function
		for (int i=0; i<10; i++) { // do a simple loop
		LOG("In the thread " << i); // log that we are in the thread instance
		Sleep(100); // sleep for 100ms
		}
		LOG("Thread is ending..."); // log end of thread instance
		});
		
	for(int i=0; i<5; i++) // do a loop in the main thread
	{
		LOG("In the main thread " << i); // log the counter
		Sleep(100); // sleep for 100ms
	}
	LOG("Waiting for thread to finish..."); // log
	t.Wait(); // wait for the thread to finish
	LOG("All threads finished");
	
	
	// Mutex
	
	Thread t2; // define a new thread instance
	Mutex m; // define a mutex to serialize a variable
	int sum=0; // define the variable that will be protected by the mutex
	t2.Run([&sum, &m] // run the thread using a lambda function
	{
		for(int i=0; i<100000; i++) // do a big loop
		{
			m.Enter(); // this will lock the mutex so other threads cannot write
			sum++; // increases value of variable
			m.Leave(); // this unlocks the mutex m, so giving access to sum again
		}
		});
	
	for(int i=0; i<100000;i++) // do a big loop in the main thread
	{
		Mutex::Lock __(m); // helper class of mutex to lock until the end of the {}
		sum++; // increase sum variable
	}
	
	t2.Wait(); // wait until the threads finishes
	DUMP(sum); // show value
	
	
	// ConditionVariable
	
	bool stop = false; // define a boolean
	BiVector<int> data; // define a bivector instance of integers
	Mutex mu; // define a mutex instance
	ConditionVariable cv; // a condition variable to control the thread flow
	
	Thread th; // define a thread instance
	th.Run([&stop, &data, &mu, &cv] // run the thread using a lambda function
	{
		Mutex::Lock __(mu); // locks the mutex inside the {}
		for (;;) // endless loop
		{
			while(data.GetCount()) // loops through data collection
			{
				int q = data.PopTail(); // pop an integer from the LIFO queue
				LOG("Data received: " << q); // logs data
			}
			if (stop) // check if the stop variable is true
				break; // break the endless loop
			cv.Wait(mu); // wait for condition variable linked to mutex mu
		}
	});
	
	for (int i=0; i<10; i++) // a classic loop
	{
		{
			Mutex::Lock __(mu); // locks the mutex inside this scope
			data.AddHead(i); // add integer to the LIFO queue
		}
		cv.Signal(); // signals the condition variable, so the thread is awakened
		Sleep(1); // wait 1ms
	}
	stop = true; // set the stop boolean
	cv.Signal(); // awaken the thread using the condition variable
	t.Wait(); // wait for thread to finish
	
	
	// CoWork
	
	long lSum; // define a long integer
	int iLoop; // define an integer
	Mutex mCowork; // define a mutex
	CoWork co; // define an instance of cowork class
	
	for (iLoop=0; iLoop < 10; iLoop++) // loop 10 times
	{
		co & [&lSum, &mCowork] // starts a new thread from the worker thread pool
		{
			if(CoWork::IsCanceled()) // check if all worker threads are canceled
			{
				LOG("Job was canceled"); // log cancellation
				return; // return from thread
			}
			Mutex::Lock __(mCowork); // using a mutex to protect variable lsum
			// CoWork::FinLock(); // replaces the mutex, locked till end of job
			for (int i=0; i<99000;i++) // a big loop
				lSum += i; // ads integer to lsum
		};
	}
	co.Finish(); // wait for all worker threads to be finished
	co.Cancel(); // cancel all worker threads, running ones will execute until ended
	DUMP(lSum); // log final result
	
	
	// AsyncWork
	
	auto a = Async([] (int n) -> double { // define a async instance using a lambda function
		double f=1; // define a double variable
		for(int i=2;i<=n;i++) // simple loop
			f *= i; // multiplication
		return f; // return result
	}, 100);
	
	DUMP(a.Get()); // the get method waits for async thread to be finished
	
	
	// CoPartition
	
	int isum=0; // define integer
	Vector<int> vdata; // define a collection
	for(int i=0;i<10000;i++) // make a big loop
		vdata.Add(i); // add loop integers to the collection
	CoPartition(vdata, [&isum](const auto& subrange) { // parallel processing of arrays using a subrange
		int partial_sum=0; // a temporary variable
		for(const auto& x : subrange) // loop through the subrange using range for loop
			partial_sum += x; // summates results
		CoWork::FinLock(); // copartition inherits cowork so we can use finlock function
		isum += partial_sum; // collect subrange result
	});
	DUMP(isum); // show result
	
	
	// CoDo
	
	Vector<String> sdata; // define collection of strings
	for (int i=0; i<100; i++) // do a loop
		sdata.Add(AsString(1.0/i)); // add rational number converted to string
	double dsum=0; // a double definition
	
	std::atomic<int> ii(0); //atomic variable, defined behavior when multiple threads write and read at the same time
	
	CoDo([&] { // define a codo instance using a lambda function
		double m=0; // define and initialize a double
		for (int i=ii++; i < sdata.GetCount(); i=ii++) // make a loop
			m += atof(sdata[i]); // summates the collection data
		CoWork::FinLock(); // protect the variable from run conditions
		dsum += m; // add the result
	});
	DUMP(dsum); // show result
	
	
	// Parallel algorithms
	
	Vector<String> x {"zero", "one", "two", "three", "four", "five", "six", "seven"}; // define a collection of strings
	DUMP(FindIndex(x, "two")); // find the index using main thread function
	DUMP(CoFindIndex(x, "two")); // find the index using concurrency function
	CoSort(x); // sort the collection using concurrency function
	DUMP(x); // show the resulting collection
}