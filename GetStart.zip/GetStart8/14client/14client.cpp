#include <Core/Core.h>
#include <Core/SSL/SSL.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	String request; // variable for user requests
	Cout() << "Connecting to server\n";
	do // loop until user enters exit command
	{
		Cout() << "Enter your server request, exit to finish:\n";
		request = ReadStdIn(); // read request from console
		TcpSocket client; // define a tcp socket client
		if(!client.Connect("127.0.0.1",1234)) // try to connect to the server
		{
			Cout() << "Connection to server failed!\n"; // connect failed
			SetExitCode(99); // set return code
			return; // exit application
		}
		client.Put(request + '\n'); // sent the request to the server
		Cout() << "Server answer from: " << request << " : " << client.GetLine() << '\n'; // get the response from the server
		client.Close(); // close the connection
	}
	while (request != "exit"); // loop until the request is "exit"
}