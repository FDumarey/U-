#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	// Ranges
	
	Vector<int> x = {1,3,5,4,100,50,40}; // define a vector of integers
	DUMP(SubRange(x,3,6)); // trim the collection from position 4 to 7
	DUMP(ConstRange(1,10)); // return a collection of 10 times "1"
	DUMP(ReverseRange(x)); // reverse the collection x
	DUMP(SortedRange(x)); // sorts the collection x
	DUMP(FilterRange(x, [](int x) {return x > 30;})); // return a collection with integers greater then 30
	
	
	// Algorithms
	
	DUMP(FindIndex(x,5)); // find the position of number 5
	DUMP(FindMin(x)); // show the position of the minimum value
	DUMP(FindMax(x)); // show the position of the maximum value
	DUMP(Min(x)); // show the minimum value
	DUMP(Max(x)); // show the maximum value
	DUMP(Count(x,100)); // count how many times value "100" is present
	DUMP(Sum(x)); // summates all values
	Sort(x); //use stablesort(x) if equal values keeps original order at a performance penalty
	DUMP(x);
	DUMP(GetSortOrder(x)); // show the order of the items as they were sorted
}
