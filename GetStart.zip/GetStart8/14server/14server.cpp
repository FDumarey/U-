#include <Core/Core.h>
#include <Core/SSL/SSL.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	Cout() << "Initializing TCP listener on port: 1234\n";
	TcpSocket server; // define a tcp socket server object
	if (!server.Listen(1234,5)) // open port 1234 with 5 queues
	{
		Cout() << "Error initializing port 1234 on current host!\n"; // error setup listener
		SetExitCode(99); // set an exit code 99
		return; // return to console
	}
	Cout() << "Server ready, waiting for requests.\n";
	for (;;) // do an unlimited loop
	{
		TcpSocket answer; // define a tcp socket for the client connection
		if (answer.Accept(server)) // if there is an incoming connection
		{
			String clientreq = answer.GetLine(); // get a line from the client connection
			Cout() << "Client requests: " << clientreq << " , from: " << answer.GetPeerAddr() << '\n'; // get info
			if (clientreq == "hello") // check the client request string
				answer.Put("ehlo"); // put an answer on the tcp socket stack for the client
			else
				answer.Put("got your message"); // put an answer on the tcp socket stack for the client
			answer.Put("\n"); // sent a newline to the client
		}
	}
}