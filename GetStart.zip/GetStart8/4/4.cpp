#include <Core/Core.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	// FileIn, FileOut and FileAppend streams
	
	FileOut out("test.txt"); // writes to a stream file
	if (!out)  // check if succesfull
	{ 
		LOG("Failed to create the file stream");
		return;
	}
	out << "Some number: " << 123 << " and point: " << Point(1,2); // write to the stream
	out.Close(); // close the stream
	
	FileIn in("test.txt"); // open a file stream
	if (!in) // check if succesfull
	{
		LOG("Failed to open the file");
		return;
	}
	in.Seek(0); // set the stream cursor at position 0
	DDUMP((char)in.Peek()); // gets one byte from the stream
	DDUMP(in.GetLine()); // gets a full line from the stream
	in.Seek(0); // set the stream cursor at position 0
	DUMP(in.Get(10)); // gets the first 10 bytes from the stream
	in.Close(); // close the stream
	
	FileAppend out2("test.txt"); // appends to an existing file stream
	out2 << "\nSome more text"; // appends some bytes
	out2.Close(); // close the append stream
	DUMP(LoadFile("test.txt")); // load the full stream in one time
	
	
	// SizeStream
	
	SizeStream szs; // define a SizeStream
	szs << "1234567"; // sends data to the counter
	DUMP(szs.GetSize()); // reads the byte counter
	
	
	// StringStream
	
	StringStream sin("123456"); // define a String stream and send data to it
	
	
	// CompareStream
	
	CompareStream cs(sin); // define a Compare stream
	cs.Put("12345"); // put data in the Compare stream
	DUMP(cs.IsEqual()); // checks the equality of the Compare stream
	
	
	// TeeStream
	
	TeeStream tee(sin, sin); // define a Tee stream
	tee << "Test tee stream"; // puts data in the two streams simultaneously
	tee.Close(); // close the stream
	DUMP(sin.GetResult()); // show the resulting stream
	
	
	// Serialization
	
	StringStream ss3; // define a String stream
	int x = 123; // define an integer
	Color h = White(); //define a U++ custom type
	ss3 % x % h; // % = Serialize function, converts all types to stream
	StringStream ss4(ss3.GetResult()); // define a stream for de serialization
	int x2; // define the integer
	Color h2; // define the custom Color type
	ss4 % x2 % h2; // operator % is used to de serialize here
	DUMP(x2);
	DUMP(h2);
	
	
	// Streams and structures
	
	struct foo // define a structure
	{
		int number; // an integer
		Color color; // a custom Color type
		void Serialize (Stream& s) // define a Serialize function
		{
			s % number % color; // % operator for serialization
		}
	};
	
	foo Myfoo; // define a struct object to write to
	Myfoo.number = 321; // set property number
	Myfoo.color = Blue(); // set property color
	String data = StoreAsString(Myfoo);  // this will use the Serialize function
	// StoreAsFile will output to a file
	foo Myfoo2; // define a struct object to read from
	LoadFromString(Myfoo2, data); // this will DeSerialize the stream
	// LoadFromFile will load from a file
	DUMP(Myfoo2.number); // show the number
	DUMP(Myfoo2.color); // show the color
}
