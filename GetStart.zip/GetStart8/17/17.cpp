#include <CtrlCore/CtrlCore.h>

using namespace Upp;

CONSOLE_APP_MAIN
{
	Cout() << "Putting some test on the clipboard\n";
	ClearClipboard(); // clear the clipboard contents
	WriteClipboardText("This is some text on the clipboard\n"); // add text to clipboard
	Cout() << ReadClipboardText() << '\n'; // read text from clipboard
	Cout() << "Appending some other text to the clipboard\n";
	AppendClipboardText("This is some appended text on the clipboard\n"); // append text to clipboard
}