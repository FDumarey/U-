#include <plugin/zip/zip.h> // include zip library

using namespace Upp;

CONSOLE_APP_MAIN {
	String filename = GetHomeDirFile("test.zip"); // define file in homefolder

	// make a zip file
	FileZip zipfile(filename); // make a filezip variable
	zipfile.WriteFolder("Folder1", GetSysTime()); // make a folder
	
	// direct string write to a file
	zipfile.WriteFile(String("some data to test the zip"), "Folder1/string.txt");
	// copy a file to a file
	zipfile.WriteFile(LoadFile(GetDataFile("15.cpp")),"Folder1/zipsource.cpp");
	// use a file handler to a zip file
	zipfile.BeginFile("file.txt");
	String somedata = "some other test data";
	zipfile.Put(somedata, strlen(somedata));
	zipfile.EndFile();
	// use a stream handler to a zip file
	OutFilterStream outstream;;
	zipfile.BeginFile(outstream, "stream.txt");
	outstream << "some content";
	outstream.Close();
	// perform zip operation and check if okay
	if(zipfile.Finish())
		Cout() << filename << " zip file created succesfully\n\n";
	
	
	// unzip a zip file
	FileUnZip unzip(filename); // make a fileunzip variable
	while(!(unzip.IsEof() || unzip.IsError())) { // repeat until end of file or error
		Cout() << "Path: " << unzip.GetPath(); // show path
		Cout() << " ,time: " << unzip.GetTime() << '\n'; // show time
		if(!unzip.IsFolder()) { // if object is file
			Cout() << "Size: " << unzip.GetLength(); // show its size
			Cout() << " ,content: " << unzip.ReadFile().Left(100) << '\n'; // show first 100 chars
		}
		else
			unzip.SkipFile(); // if folder then skip file
	}
}