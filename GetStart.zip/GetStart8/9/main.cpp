#include <Core/Core.h>

using namespace Upp;

double Expression(CParser& parser); // define prototype because needed before

double Terms(CParser& parser) // the terms level
{
	Cout() << "In terms function" << '\n';
	if(parser.Id("cos")) { // if cos found
		parser.PassChar('('); // skip ( character
		double x = Expression(parser); // get expression value
		parser.PassChar(')'); // skip ) character
		return cos(x); // return cosine value
	}
	if(parser.Id("sin")) { // if sin found
		parser.PassChar('('); // skip ( character
		double x = Expression(parser); // get expression value
		parser.PassChar(')'); // skip ) character
		return sin(x); // return sinus value
	}
	if(parser.Char('(')) { // if parenthesis found
		double x = Expression(parser); // get expression value
		parser.PassChar(')'); // skip ) character
		return x; // return expression value
	}
	double x = parser.ReadDouble(); // read terms value = double floating point
	Cout() << "    return terms value=" << x << '\n';
	return x; // return terms value
}

double Multiply(CParser& parser) // the multiply level
{
	Cout() << "In multiplier function." << '\n';
	double x = Terms(parser); // go to terms level and assign value
	Cout() << "   init multiply value=" << x << '\n';
	for(;;) // do a endless loop
		if(parser.Char('*')) // if multiplication
			x = x * Terms(parser); // multiply terms recursion
		else
		if(parser.Char('/')) { // if division
			double y = Terms(parser); // divide terms recursion
			if(0 == y) // if divider is zero
				parser.ThrowError("Division by zero not allowed"); // throw error
			x = x / y; // divide
		}
		else {
			Cout() << "    return multiply value=" << x << '\n';
			return x; // return multiply value
		}
}

double Expression(CParser& parser) // the expression level
{
	Cout() << "In expression function." << '\n';
	double x = Multiply(parser); // go to multiply level and assign value
	Cout() << "   init expression value=" << x << '\n';
	for(;;) // do a endless loop
		if(parser.Char('+')) // if addition
			x = x + Multiply(parser); // add multiply recursion
		else
		if(parser.Char('-')) // if subtraction
			x = x - Multiply(parser); // negate multiply recursion
		else {
			Cout() << "    return expression value=" << x << '\n';
			return x; // return expression value
		}
}

CONSOLE_APP_MAIN
{
		Cout() << "Enter a numerical expression: x= ";
		String linein = ReadStdIn(); // read from standard in
		CParser parser(linein); // define a cparser object
		try
		{
		Cout() << Expression(parser) << '\n'; // call the expression level
		}
		catch(CParser::Error e) { // if a parsing error occurs
			Cout() << "Parsing error: " << e << '\n'; // print error
		}
}