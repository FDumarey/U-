#include <Core/Core.h>
#include <shellapi.h> // for ShellExecute Win32 API

using namespace Upp;

CONSOLE_APP_MAIN
{
	Cout() << "Opening the explorer and selecting bootmgr file in c: system drive\n";
	String strArgs = "/select, C:\\bootmgr"; // defina some arguments
	ShellExecute(0, "open", "explorer.exe", strArgs, 0, SW_NORMAL); // execute shell command
	
	Cout() << "Launching web browser to U++ home site\n";
	LaunchWebBrowser("https://www.ultimatepp.org/index.html"); // execute the default web browser
}